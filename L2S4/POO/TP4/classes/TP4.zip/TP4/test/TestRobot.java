import org.junit.*;
import static org.junit.Assert.*;

import example.Robot;
import example.util.Box;
import example.util.ConveyerBelt;

public class TestRobot {

    @Test
    public void testTake() {
        Box someBox = new Box(10);
        Robot newRobot = new Robot();

    }

    @Test
    public void testCarryBox() {
        Box someBox = new Box(10);


      }

    @Test
    public void testPutOn() {
      Box someBox = new Box(10);
      ConveyerBelt createConveyerBelt = new ConveyerBelt(20);

      }


    // ---Pour permettre l'exécution des test----------------------
    public static junit.framework.Test suite() {
        return new junit.framework.JUnit4TestAdapter(BoxTest.class);
    }

}
