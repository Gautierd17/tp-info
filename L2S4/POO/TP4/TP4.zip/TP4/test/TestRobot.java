import org.junit.*;
import static org.junit.Assert.*;

import example.Robot;
import example.util.Box;
import example.util.ConveyerBelt;

public class TestRobot {

    @Test
    public void testTake() {
        Robot newRobot = new Robot();
        Box newBox1 = new Box(10);
        newRobot.take(newBox1); // box has been taken
        assertNotNull(newRobot.carryBox());
    }

    @Test
    public void testCarryBox() {
        // case 1 : box has been taken
        Box someBox1 = new Box(10);
        Robot someRobot1 = new Robot();
        someRobot1.take(someBox1);
        assertTrue(someRobot1.carryBox());

        // case 2 : no box taken
        Box someBox2 = new Box(20);
        Robot someRobot2 = new Robot();
        ConveyerBelt belt = new ConveyerBelt(100);
        someRobot2.take(someBox2);
        someRobot2.putOn(belt);
        assertFalse(someRobot2.carryBox());
      }

    @Test
    public void testPutOn() {
        Robot createRobot = new Robot();
        Box createBox = new Box(10);
        ConveyerBelt createBelt = new ConveyerBelt(100);
        createRobot.take(createBox); // take a box
        createRobot.putOn(createBelt); // put box on belt
        // belt is not full now (capacity = 2)
        assertFalse(createBelt.isFull());
        assertFalse(createRobot.carryBox()); // robot don't have any box now

        // testing if belt is full
        Box createBox2 = new Box(20);
        createRobot.take(createBox2);
        createRobot.putOn(createBelt);
        assertTrue(createBelt.isFull());
      }


    // ---Pour permettre l'exécution des test----------------------
    public static junit.framework.Test suite() {
        return new junit.framework.JUnit4TestAdapter(TestRobot.class);
    }

}
