<?php
require_once('lib/auth.php');
$ident = $_SESSION['ident']; 
?>
<!DOCTYPE html>                                        
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">                              
  <head>                                                                                         
    <meta charset="UTF-8"/>                         
    <title>Page à accès contrôlé</title>
  </head>
<body>
<h1>
  
<?php echo "Bienvenue ". $ident->getPrenom() . " " .$ident->getNom();
?>
</h1>
<a href="logout.php">Se déconnecter</a>
</body>
</html>
