<?php
 require('lib/biblio.php');
 session_start();
 try {
   controleAuthentification();
 }
 catch(Exception $e)
 { 
   require('lib/formuLogin.php');
   exit();
 }
?>