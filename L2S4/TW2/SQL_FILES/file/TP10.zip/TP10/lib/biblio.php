<?php
function __autoload($className)
{
  include 'lib/'.$className . '.class.php';
}

//require_once('lib/Identite.class.php');
define('FICHIER_PASSWORD','lib/password.txt');

/* Renvoie un tableau de 4 chaînes contenant les prochain
     login, password, nom et prenom
   puisés dans le fichier $file
  Renvoie null en fin de fichier ou si la prochaine ligne n'a pas le bon format
*/
function getUser($file)
{
 $ligne = fgets($file);
 if (! $ligne)
   return null;
 $tab = explode(";",$ligne);
 if (count($tab) != 4)
  return null;
 return $tab;
}

/*
  Si login et password sont corrects, alors
  le résultat est une instance d'Identite décrivant cet utilisateur
  Sinon le résultat vaut null
*/
function authentifier($login, $password)
{
 $file = fopen(FICHIER_PASSWORD,'r');
 $user = getUser($file);
 while ($user)
 {
   if ($login===$user[0] && $password===$user[1])
   {
     fclose($file);
     return new Identite($user[0],$user[2],$user[3]);
   }
   $user= getUser($file);
 }
 fclose($file);
 return null;
}

/*
 Verifie l'authentification
 La fonction se termine normalement
 - Si l'état de la session indique que l'authentification a déjà eu lieu
 - Si des paramètres login/password corrects ont été fournis
 Après exécution correcte,  $_SESSION['ident'] contient l'identité de l'utilisateur
 Dans tous les autres cas, une exception est déclenchée
*/
function controleAuthentification()
{
  if (isset($_SESSION['ident']))
   return;
   $login = inputFilterString('login');
   $password = inputFilterString('password');
 // if (! isset($_REQUEST['login'])  || ! isset($_REQUEST['password']))
 //   throw new Exception('aucune authentification possible');
  $ident = authentifie($login,$password);
  if (! $ident)
   { $_SESSION['echec']=TRUE;
     throw new Exception('login/password incorrects');
   }
  $_SESSION['ident'] = $ident;  //ou serialize($ident);
  unset($_SESSION['echec']); // au cas où c'était positionné
}

function inputFilterString($name, $requis=TRUE){
  $v = filter_input(INPUT_POST, $name, FILTER_SANITIZE_STRING);
  if ( $requis && $v == NULL )
    throw new Exception("argument $name est requis");
 return $v;
}

?>
